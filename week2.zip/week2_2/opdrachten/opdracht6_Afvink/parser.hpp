#ifndef _PARSER_HPP_
#define _PARSER_HPP_

#define WS_LIST_SIZE 6

class PARSER {
	public:
		bool tokenizer(char *input, char *tokens[]);	
		
	private:
};

#endif